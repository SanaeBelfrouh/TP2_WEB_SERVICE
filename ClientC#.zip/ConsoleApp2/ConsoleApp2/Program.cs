﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace banqueclient
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            ServiceReference1.BanqueServiceClient bn = new ServiceReference1.BanqueServiceClient();
            double montant = 200;

            ServiceReference1.ConvertRequest convertRequest = new ServiceReference1.ConvertRequest(montant);
            ServiceReference1.ConvertResponse convertResponse = await bn.ConvertAsync(200);
            Console.WriteLine($"Le montant {montant} $ en DH est {convertResponse.@return}");

            ServiceReference1.getCompteRequest compteRequest = new ServiceReference1.getCompteRequest { code = 1 };
            ServiceReference1.getCompteResponse compteResponse = await bn.getCompteAsync(2);
            Console.WriteLine($"Le solde du compte {compteResponse.@return.code} est {compteResponse.@return.solde}");

            Console.Read();
        }
    }
}