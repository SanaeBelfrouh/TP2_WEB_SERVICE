import mypackage.BanqueService;
import mypackage.BanqueWs;
import mypackage.Compte;

public class ClienWS {
    public static  void main(String[] args) {
        //creation du middleware
        BanqueService stub=new BanqueWs().getBanqueServicePort();
        System.out.println(stub.convert(7600));
        Compte cp=stub.getCompte(6);
        System.out.println("Code du compte: " +cp.getCode());
        System.out.println("Solde du compte: " + cp.getSolde());

    }
}
