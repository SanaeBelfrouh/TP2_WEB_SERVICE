@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://ws/")
package mypackage;
